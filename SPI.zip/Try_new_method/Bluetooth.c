/*
 * File:        TFT_keypad_BRL4.c
 * Author:      Bruce Land
 * Adapted from:
 *              main.c by
 * Author:      Syed Tahmid Mahbub
 * Target PIC:  PIC32MX250F128B
 */

// graphics libraries
#include "config.h"
#include "tft_master.h"
#include "tft_gfx.h"

#define _SUPPRESS_PLIB_WARNING

// need for rand function
#include <stdlib.h>

// threading library
#include <plib.h>
// config.h sets 40 MHz
#define	SYS_FREQ 40000000
#include "pt_cornell_1_1.h"

/* Demo code for interfacing TFT (ILI9340 controller) to PIC32
 * The library has been modified from a similar Adafruit library
 */
// Adafruit data:
/***************************************************
  This is an example sketch for the Adafruit 2.2" SPI display.
  This library works with the Adafruit 2.2" TFT Breakout w/SD card
  ----> http://www.adafruit.com/products/1480

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution
 ****************************************************/
#define DAC_config_chan_A 0b0011000000000000
#define DAC_config_chan_B 0b1011000000000000
#define PRESCALE 1          //TODO: CHANGE IF WE CHANGE THE PRESCALE
#define PERIOD 400.0f
#define TM2_FREQ (SYS_FREQ/PERIOD)
#define TM2_DURA 1.0/TM2_FREQ
#define freq 1000.0
//#define Fs (100.0/(freq*TM2_DURA))
#define two32 4294967296.0 // 2^32 
#include <math.h>

volatile SpiChannel spiChn = SPI_CHANNEL2 ;	// the SPI channel to use
volatile int spiClkDiv = 2 ; // 15 MHz DAC clock

// === 16:16 fixed point macros ==========================================
#define sine_table_size 16


//== Timer 2 interrupt handler ===========================================
// actual scaled DAC 
volatile  int DAC_data = 2047, quadrature_data;
// ADC output
volatile  int ADC_net;	// conversion result as read from result buffer
// the DDS units:
 int Fs = (100.0/(2000*TM2_DURA));
volatile unsigned int phase_accum_main, phase_incr_main=100.0*two32/(100.0/(2000*TM2_DURA)) ;//
// profiling of ISR
volatile int isr_time;
volatile int I_signal, Q_signal ;
//volatile int sine_index ;

// averaging the signal
int avg_size = 50000;
volatile int avg_count;
// accumulators
volatile long long I_avg, Q_avg;
// and the final averages
float I_out, Q_out, I_out_base, Q_out_base ;

unsigned int main_cnt = 0;

// Five Parameters
int chirp_repeat_interval = 150;
int num_of_syllables = 2, syll_cnt = 2;
int syl_duration = 30;
int syl_rpt_int = 50;
int burst_freq = 2000;

// Counter for one single syllable
unsigned int syll_start = 0;

// Variable for envelope
#define ENV_RAMP (1.0f/400.0f)
#define ENV_ZERO 0.0f
#define ENV_FULL 1.0f
float env_val = 0;

// User Interface States
enum ux_state {
    select_parameter,
    set_parameter,
    playing,
    test_mode
};

// Struct to organize parameters
struct parameter {
    const char* name;
    int digits;
    int min_val;
    int max_val;
    int val;
};

static enum ux_state _state = select_parameter;
char buffer[60];

// Used for debouncing

static struct pt pt_timer, pt_color, pt_anim, pt_key, pt_key_alt ;

// system 1 second interval tick
int sys_time_seconds;
int j=0;


#define TEST_MODE_FREQ 1000

// === Timer Thread =================================================
// update a 1 second tick counter

static PT_THREAD (protothread_timer(struct pt *pt))
{
    PT_BEGIN(pt);
    while(1) {
    PT_YIELD_TIME_msec(10) ;
    mPORTBClearBits(BIT_4); // start transaction
    mPORTBSetBits(BIT_4);
    PT_YIELD_TIME_msec(1)
    WriteSPI2(0b00000001);
    } // END WHILE(1)
  PT_END(pt);
} // timer thread


// === Main  ======================================================
void main(void) {
    SYSTEMConfigPerformance(PBCLK);
    ANSELA = 0; ANSELB = 0; CM1CON = 0; CM2CON = 0;
    PT_setup();
    PT_INIT(&pt_timer);
    
    srand(1);
    // Enable timer2
    INTEnableSystemMultiVectoredInt();
    // Enable SPI2    
    PPSOutput(2, RPB5, SDO2);
    mPORTBSetPinsDigitalOut(BIT_4);
    mPORTBSetBits(BIT_4);
    SpiChnOpen(spiChn, SPI_OPEN_ON | SPI_OPEN_MODE8 | SPI_OPEN_MSTEN | SPI_OPEN_CKE_REV , spiClkDiv);
    while (1) {
        PT_SCHEDULE(protothread_timer(&pt_timer));
    }
} // main

// === end  ======================================================

