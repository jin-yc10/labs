import numpy as np
import matplotlib.pyplot as plt
import os 
import sys

ax1 = plt.subplot(111)

data = sys.argv[1]


temp_x = []
temp_y = []

num = 0
for i in data:
	temp_x.append(num)
	temp_x.append(num+0.99)
	temp_y.append(i)
	temp_y.append(i)
	num += 1

plt.plot(temp_x,temp_y)
plt.sca(ax1)

os.chdir("web/app/static/")
filename = 'test' + sys.argv[2] + '.png'
plt.savefig(filename)
os.chdir("../../../")


# plt.show()