# This script judges the downlaod and upload of the wave information to uart side.
# Use redis to record the state (If write or read)

# It's a call and response programming. When you need to record, you should click on the record button 
# If you want to send the data, just press the send button.
# The communication of two python script is through redis.

# Redis database (host='localhost', port=6379, db=2)
# Redis data(0,check the state)
# Redis data(1,the data we have)

import serial
import redis
import glob as gb
import os


def order_detector():
	# return the name of file
	os.chdir("web/app/static")
	img_dic = gb.glob("*.png")
	os.chdir("../../..")
	temp_array = []
	for img_name in img_dic:
		temp = img_name[4:]
		temp = temp[:-4]
		temp_array.append(int(temp))
	count = 0
	for number in sorted(temp_array):
	 	if number != count:
	 		break
	 	else:
	 		count += 1
	return count
		
print order_detector()


def initialize()
	# Initialize serial port 
	s_port=serial.Serial()
	s_port.port = "/dev/tty.usbserial"
	s_port.baudrate = 38400
	s_port.bytesize = 8
	s_port.parity = "N"
	s_port.stopbits = 1
	s_port.timeout = 5
	s_port.open()
	return s_port

serial_port = initialize()

try:
	while true:
		# Data is come from redis first bit. 
		if data==0:
			# Idel here;
			pass
		if data==1:
			# Record the state.
			serial_port.write("send_record_instruction")
			wave_data = serial_port.read(200)
			number_order = order_detector
			instruction = "python matploter.py " + wave_data + number_order + '&'
			os.system(instruction) 
			# Add this data to redis.
			# plot this data. (run matploter.py)
			pass
		if data==2:
			# send the data
			serial_port.write("send_send_instruction")
			serial_port.write("data")
			pass
except:
	serial_port.close()
