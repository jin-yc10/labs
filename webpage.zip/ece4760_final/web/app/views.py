from flask import render_template, request
from app import app
import redis
import glob as gb
import os

dic = {}
r = redis.StrictRedis(host='localhost', port=6379, db=0)


@app.route('/')
@app.route('/index',methods = ['POST', 'GET'])
def index():
    user = {'nickname': 'User'}  # fake user

    os.chdir("app/static")
    img_path = gb.glob("*.png")
    os.chdir("../..")
    num = 0
    for i in img_path:
      dic[num] = '/static/' + i
      num += 1

    if request.method == 'POST':
      if request.form['submit'] == 'do_0':
        print 0
      if request.form['submit'] == 'do_1':
        print 1
      if request.form['submit'] == 'do_2':
        print 2
      if request.form['submit'] == 'record':
        print 3
    # if request.form['submit'] == 'Do Something':
    #   print 1

    return render_template("index.html",
                           title='Home',
                           user=user,
                           posts=dic)

